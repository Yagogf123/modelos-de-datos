<template>
  <div class="col-4 noticia">
    <p>{{ noticia.name }}</p>
    <p>{{ noticia.variations[0].description }} </p>
    <img :src="'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/'+ noticia.num + '.png'" />
  </div>
</template>

<script>
export default {
    props: {
        noticia: Object,
    },
};
</script>

<style>
.noticia{
    height: 300px;
    display: flex;
    flex-direction: column;
    align-items: center;
    border: 1px solid grey;
}

.noticia img{
    max-height: 200px;
    max-width: 250px;
}
</style>