<template>
  <div>
    <h1>{{ title }}</h1>
    <div class="row">
      <template v-for="pokemonItem in pokemon" :key="pokemonItem.id">
        <Pokemon :pokemon="pokemonItem" />
      </template>
    </div>
  </div>
</template>

<script>
import { onMounted, computed } from "vue";
import { useStore } from "vuex";
import Pokemon from "./Animales.vue"; // Asegúrate de tener el componente Pokemon adecuado

export default {
  components: {
    Pokemon,
  },
  setup() {
    const store = useStore();

    onMounted(() => {
      store.dispatch("getAnimales");
    });

    const pokemon = computed(() => store.state.pokemon);
   
    return {
      title: store.state.titleApp,
      pokemon,
    };
  },
};
</script>

<style>
h1 {
  text-align: center;
}
</style>
