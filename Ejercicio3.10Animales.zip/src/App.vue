<template>
  <div class="container">
    <list-pokemon />
  </div>
</template>

<script>
import ListPokemon from './components/ListPokemon.vue';

export default {
  name: 'App',
  components: {
    ListPokemon,
  },
};
</script>

<style></style>
