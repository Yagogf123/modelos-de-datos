import { createStore } from 'vuex'

export default createStore({
  state: {
    titleApp: "Animales",
    pokemon: [],
  },
  getters: {
    
    imagenesAnimales: state => state.pokemon.map(pokemon => pokemon.foto),
  },
  mutations: {
    setPokemon(state, payload)
    {
      state.pokemon = payload;
    },
  },
  
  actions: {
    async getPokemon ({commit}){
      try{
        const response = await fetch("https://raw.githubusercontent.com/Yagogf123/modelos-de-datos/main/animales.json")
        const result = await response.json();
        commit("setPokemon", result);
        console.log("Mis pokemon");
        console.log(result);
      }
      catch(error){
        console.log(error);
      }
    },
  },
  modules: {
  }
})
